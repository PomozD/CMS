
jQuery(document).ready(function(e) {



  art_pos_fixed();
  category_same_article();

  var license = jQuery('.s2s_backend_license_js_check').val();

  if(license=='0'){
    jQuery('.fa-star-o').parent().click(function(){
        //alert(license);

        var mylicensewarning = '<div class="alert alert-error"> This is a PRO feature. Changes will not be saved. </div>';
        
        if(jQuery(this).parents('.control-group').children('.alert').length <= 0){
          jQuery(this).parents('.control-group').append(mylicensewarning);
        }

    });
    //disable button
    jQuery('.fa-star-o').parent().addClass('disabled');
    jQuery('.fa-star-o').parent().attr( "disabled", "disabled" );

    //funny error with modern base
    jQuery('#jform_params_social2s_base1').attr('checked', 'checked');
    jQuery('#jform_params_social2s_base1').attr('checked', '');
  }




//J3.0
if(s2s_version >='3.0'){
  //ACCORDIONS
  jQuery('.accordion-group').each(function(index, value){

    jQuery(this).children('.accordion-body').append(jQuery(this).children('.control-group'));
    jQuery(this).unwrap();

  });

  //current version
  //var current_version = jQuery('#s2s_db_version').val();
  //console.log(current_version);
  //jQuery('.s2s_version h4').append(' <span class="badge">db:'+current_version+'</span>');

  /*3.1.6 scrollto*/

  jQuery('.accordion-heading').click(function(){

    console.log(jQuery(this));

      jQuery('html, body').animate({
          scrollTop: jQuery(this).offset().top-100
      }, 400);

  });

}else{
//J2.5 FALLBACK
/**/
  //ACCORDIONS
  jQuery('.s2s_j25_splitter').each(function(index, value){

    jQuery(this).parent('li').addClass('s2s_j25_li_splitter');

    //jQuery(this).children('.accordion-body').append(jQuery(this).children('.control-group'));
  });

}

    /*ORDER*/
    try{

            jQuery( "#sortable" ).sortable({

                stop:function(event,ui){ 

                //get order
                var orden = jQuery('.s2s_order li');
                var order_num = '';

                //bucle order
                jQuery.each(orden, function(index, value){

                    order_num += jQuery(value).attr('data-s2s');
                    if(index <=7){
                    order_num +=',';
                    }
                });
                jQuery('.input_s2s_orden').val(order_num);
                
                }

            });

    }catch(e){
        jQuery('#jform_params_s2s_order-lbl .fa-hand-rock-o').addClass('alert alert-danger').html(' not supported :( <br> Something is wrong with your sortable');
    }


        
   
    
    
});


function apply_cool_stuff(){
  //modern
  jQuery('#jform_params_social2s_base0').attr('checked', '');
  jQuery('#jform_params_social2s_base1').attr('checked', 'checked');
  //twitter cards
  jQuery('#jform_params_twitter_cards0').attr('checked', '');
  jQuery('#jform_params_twitter_cards1').attr('checked', 'checked');
  //fill mode
  jQuery('#jform_params_s2s_art_fill0').attr('checked', '');
  jQuery('#jform_params_s2s_art_fill1').attr('checked', '');
  jQuery('#jform_params_s2s_art_fill2').attr('checked', 'checked');

  //fast load twitter
  jQuery('#jform_params_twitter_fast_as_light0').attr('checked', '');
  jQuery('#jform_params_twitter_fast_as_light1').attr('checked', 'checked');

  //remove credits
  jQuery('#jform_params_s2s_credits0').attr('checked', 'checked');
  jQuery('#jform_params_s2s_credits0').attr('checked', '');

}


function art_pos_fixed(){

  //actualizo las clases de categoria
  var pos_fixed_button = jQuery("#jform_params_s2s_art_fixed input:checked").val();

  //if same, invalido valores
  if(pos_fixed_button==0){
    jQuery("#jform_params_s2s_art_mobile_min").addClass('disabled');
    jQuery("#jform_params_s2s_art_fixed_mode").addClass('disabled');
    jQuery("#jform_params_s2s_art_fixed_posx").addClass('disabled');
    jQuery("#jform_params_s2s_art_fixed_posy").addClass('disabled');

    //jQuery("#jform_params_s2s_takefromarticle").removeClass('disabled');
  }else{
    jQuery("#jform_params_s2s_art_mobile_min").removeClass('disabled');
    jQuery("#jform_params_s2s_art_fixed_mode").removeClass('disabled');
    jQuery("#jform_params_s2s_art_fixed_posx").removeClass('disabled');
    jQuery("#jform_params_s2s_art_fixed_posy").removeClass('disabled');
  }

  //modify on click
  jQuery("#jform_params_s2s_art_fixed").on('change', function(){

    var pos_fixed_button = jQuery("#jform_params_s2s_art_fixed input:checked").val();
    if(pos_fixed_button==0){
      jQuery("#jform_params_s2s_art_mobile_min").addClass('disabled');
      jQuery("#jform_params_s2s_art_fixed_mode").addClass('disabled');
      jQuery("#jform_params_s2s_art_fixed_posx").addClass('disabled');
      jQuery("#jform_params_s2s_art_fixed_posy").addClass('disabled');
      //jQuery("#jform_params_s2s_takefromarticle").removeClass('disabled');
    }else{
      var s2s_backend_license_js_check = jQuery(".s2s_backend_license_js_check").val();
      
      if(s2s_backend_license_js_check){
        jQuery("#jform_params_s2s_art_mobile_min").removeClass('disabled');
        jQuery("#jform_params_s2s_art_fixed_mode").removeClass('disabled');
        jQuery("#jform_params_s2s_art_fixed_posx").removeClass('disabled');
        jQuery("#jform_params_s2s_art_fixed_posy").removeClass('disabled');
      }else{
        jQuery(this).children('.active').removeClass('btn-success');
        if(jQuery(this).parent().children('.s2slicensemsg').length <=0){
          jQuery(this).after('<span class="alert alert-warning s2slicensemsg">Pro license required</span>');
        }

      }

    }

  });

}

function category_same_article(){


  //actualizo las clases de categoria
  var cat_same = jQuery("#jform_params_s2s_takefromarticle input:checked").val();

  //if same, invalido valores
  if(cat_same==1){
    jQuery("#attrib-SOCIAL2S_CATEGORIES .btn-group").addClass('disabled');
    jQuery("#jform_params_s2s_takefromarticle").removeClass('disabled');
  }else{
    jQuery("#attrib-SOCIAL2S_CATEGORIES .btn-group").removeClass('disabled');
  }

  //modify on click
  jQuery("#jform_params_s2s_takefromarticle").on('change', function(){

    var cat_same = jQuery("#jform_params_s2s_takefromarticle input:checked").val();
    if(cat_same==1){
      jQuery("#attrib-SOCIAL2S_CATEGORIES .btn-group").addClass('disabled');
      jQuery("#jform_params_s2s_takefromarticle").removeClass('disabled');
    }else{
      jQuery("#attrib-SOCIAL2S_CATEGORIES .btn-group").removeClass('disabled');
    }

  });

}
