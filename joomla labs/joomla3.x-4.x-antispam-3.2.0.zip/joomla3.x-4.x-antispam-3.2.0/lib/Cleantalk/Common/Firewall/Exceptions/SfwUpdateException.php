<?php

namespace Cleantalk\Common\Firewall\Exceptions;

class SfwUpdateException extends \Exception
{

}