DROP TABLE IF EXISTS `#__cleantalk_sfw`;
DROP TABLE IF EXISTS `#__cleantalk_sfw_logs`;
DROP TABLE IF EXISTS `#__cleantalk_sessions`;
DROP TABLE IF EXISTS `#__cleantalk_ua_bl`;