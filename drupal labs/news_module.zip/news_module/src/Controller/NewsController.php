<?php

  namespace Drupal\news_module\Controller;

  use Drupal\Core\Controller\ControllerBase;

  class NewsController
  {
    public function showContent() {
      return [
        '#type' => 'markup',
        '#markup' => "<h1>News</h1>",
      ];
    }
  }
