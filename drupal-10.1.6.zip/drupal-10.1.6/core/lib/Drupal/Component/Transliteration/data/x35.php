<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'lue', 'deng', 'lin', 'jue', 'su', 'xiao', 'zan', NULL, NULL, 'zhu', 'zhan', 'jian', 'zou', 'chua', 'xie', 'li',
  0x10 => NULL, 'chi', 'xi', 'jian', NULL, 'ji', NULL, 'fei', 'chu', 'beng', 'jie', NULL, 'ba', 'liang', 'kuai', NULL,
  0x20 => 'xia', 'bie', 'jue', 'lei', 'xin', 'bai', 'yang', 'lu', 'bei', 'e', 'lu', NULL, NULL, 'che', 'nuo', 'xuan',
  0x30 => 'heng', 'yu', NULL, 'gui', 'yi', 'xuan', 'gong', 'lou', 'ti', 'le', 'shi', NULL, 'sun', 'yao', 'xian', 'zou',
  0x40 => NULL, 'que', 'yin', 'xi', 'zhi', 'jia', 'hu', 'la', 'yi', 'ke', 'fu', 'qin', 'ai', NULL, 'ke', 'chu',
  0x50 => 'xie', 'chu', 'wei', NULL, NULL, 'huan', 'su', 'you', NULL, 'jun', 'zhao', 'xu', 'shi', NULL, 'shua', 'kui',
  0x60 => 'shuang', 'he', 'gai', 'yan', 'qiu', 'shen', 'hua', 'xi', 'fan', 'pang', 'dan', 'fang', 'gong', 'ao', 'fu', 'ne',
  0x70 => 'xue', 'you', 'hua', NULL, 'chen', 'guo', 'n', 'hua', 'li', 'fa', 'xiao', 'pou', NULL, 'si', NULL, NULL,
  0x80 => 'le', 'lin', 'yi', 'hou', NULL, 'xu', 'qu', 'er', NULL, NULL, 'xun', NULL, NULL, NULL, NULL, 'nie',
  0x90 => 'wei', 'xie', 'ti', 'hong', 'tun', 'nie', 'nie', 'yin', 'zhen', NULL, NULL, NULL, NULL, NULL, 'wai', 'shou',
  0xA0 => 'nuo', 'ye', 'qi', 'tou', 'han', 'jun', 'dong', 'hun', 'lu', 'ju', 'huo', 'ling', NULL, 'tian', 'lun', NULL,
  0xB0 => NULL, NULL, NULL, NULL, NULL, 'ge', 'yan', 'shi', 'xue', 'pen', 'chun', 'niu', 'duo', 'ze', 'e', 'xie',
  0xC0 => 'you', 'e', 'sheng', 'wen', 'ku', 'hu', 'ge', 'xia', 'man', 'lue', 'ji', 'hou', 'zhi', NULL, NULL, 'wai',
  0xD0 => NULL, 'bai', 'ai', 'zhui', 'qian', 'gou', 'dan', 'bei', 'bo', 'chu', 'li', 'xiao', 'xiu', NULL, NULL, NULL,
  0xE0 => NULL, NULL, 'hong', 'ti', 'cu', 'kuo', 'lao', 'zhi', 'xie', 'xi', NULL, 'qie', 'zha', 'xi', NULL, NULL,
  0xF0 => 'cong', 'ji', 'huo', 'ta', 'yan', 'xu', 'po', 'sai', NULL, NULL, NULL, 'guo', 'ye', 'xiang', 'xue', 'he',
];
